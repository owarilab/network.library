オンメモリのKVS

GET : データ取得
SET : データ設定
DELETE : データ削除
KEYS : キー一覧の取得

の４コマンドを用意
