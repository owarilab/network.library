// room command
#define PAYLOAD_TYPE_CREATE_ROOM 0x01
#define PAYLOAD_TYPE_JOIN_ROOM 0x02
#define PAYLOAD_TYPE_LEAVE_ROOM 0x03

//broadcast 4~1000
#define PAYLOAD_TYPE_BROADCAST 4
#define PAYLOAD_TYPE_BROADCAST_END 1000

//othercast 1001~2000
#define PAYLOAD_TYPE_OTHERCAST 1001
#define PAYLOAD_TYPE_OTHERCAST_END 2000

GDT_SOCKET_OPTION* option;

int main()
{
	option = gdt_create_tcp_client("localhost", "1024");
	gdt_set_recv_buffer(option, SIZE_KBYTE * 256);
	gdt_set_send_buffer(option, SIZE_KBYTE * 256);
	gdt_set_message_buffer(option, SIZE_KBYTE * 256);
	set_on_connect_event(option, on_connect);
	set_on_payload_recv_event(option, on_payload_recv);
	set_on_close_event(option, on_close);
	gdt_socket(option);
	char id[20];
	_snprintf_s(id, sizeof(id), "room_id_%d", selectIndex);
	// 部屋を作成
	gdt_client_send_message(PAYLOAD_TYPE_CREATE_ROOM, id, strlen(id), option);
	return 0;
}

int on_connect(GDT_SERVER_CONNECTION_INFO* connection)
{
	return 0;
}

int32_t on_payload_recv(uint32_t payload_type, uint8_t* payload, size_t payload_len, GDT_RECV_INFO *gdt_recv_info)
{
	total_recv_packets += payload_len;
	char *pbuf = (char*)payload;
	pbuf[payload_len] = '\0';
	// create room
	if (payload_type == PAYLOAD_TYPE_CREATE_ROOM) {
		if (!strcmp("1", pbuf)) {
			// 部屋作成成功
			is_join = 1;
		}
		if (!strcmp("2", pbuf)) {
			// 部屋が存在するので参加
			int selectIndex = (int)SendMessage(hListBox, LB_GETCURSEL, 0, 0);
			if (selectIndex < 0) {
				selectIndex = 0;
			}
			char id[20];
			_snprintf_s(id, sizeof(id), "room_id_%d", selectIndex);
			safeSend(PAYLOAD_TYPE_JOIN_ROOM, id, strlen(id), option);
		}
	}
	// join room
	if (payload_type == PAYLOAD_TYPE_JOIN_ROOM) {
		if (!strcmp("1", pbuf)) {
			// 部屋参加に成功
			is_join = 1;
		}
	}
	// leave room
	if (payload_type == PAYLOAD_TYPE_LEAVE_ROOM) {
		if (!strcmp("1", pbuf)) {
			// 部屋退室に成功
			is_join = 0;
		}
	}
	// broadcast
	if (payload_type == PAYLOAD_TYPE_BROADCAST) {
		SendMessage(hMessageBox2, LB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)pbuf);
		messageId++;
	}
	return 0;
}

int on_close(GDT_SERVER_CONNECTION_INFO* connection)
{
	return 0;
}
