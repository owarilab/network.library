お手製のWEBサーバ

# 使い方
・wwwディレクトリ以下にhtmlなどのファイルを配置
・webserver.exeを起動( 外部通信を待ち受けるためネットワークの許可を求められる )
・ポートが8080番で待ち受けているためURLは「http://localhost:8080/index.html」などで接続可能

# 対応メソッド
・HEAD
・GET
(POST,DELETE,PUTリクエストは未対応)

# 配信可能なファイルの拡張子
　.html
　.css
　.js
　.png
　.ico
